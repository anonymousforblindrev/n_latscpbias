The folder "task_local_demo" contains the program code for a local demo version of the online experiment. 
The experiment was programmed with JSPsych (see: https://www.jspsych.org/7.0/) and
the online study was hosted via Cognition.run (see: https://www.cognition.run/login) 

